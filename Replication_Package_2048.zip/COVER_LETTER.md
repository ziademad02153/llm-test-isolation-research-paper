# Cover Letter for Submission to SN Computer Science (Springer Nature)

**Date:** November 15, 2026  
**To:** Editor-in-Chief, *SN Computer Science*, Springer Nature  
**From:** Ziad Emad Allam  
The American University in Cairo (AUC), New Cairo, Egypt  
Email: `z.e.ziad@xed.aucegypt.edu`  
ORCID: [0009-0008-4323-791X](https://orcid.org/0009-0008-4323-791X)  

---

**Subject:** Submission of Original Research Manuscript:  
*"Separating Test Synthesis from Implementation Inspection: An Empirical Factorial Study of Oracle Validity, Code Exposure, and Test Harness Scoping in LLM Testing"*

Dear Editor-in-Chief,

I am pleased to submit our original research manuscript entitled **"Separating Test Synthesis from Implementation Inspection: An Empirical Factorial Study of Oracle Validity, Code Exposure, and Test Harness Scoping in LLM Testing"** for consideration as a regular research article in *SN Computer Science*.

### Context & Core Contribution
A growing body of empirical software engineering research evaluates Large Language Models (LLMs) for automated unit test generation. However, evaluating LLM-generated tests presents severe, unaddressed infrastructural challenges. 

The primary contribution of this paper is the discovery and formal analysis of the **"Function Definition Shadowing Artifact"** inherent in conventional naive execution harnesses. In typical benchmarking workflows, model completions are naively concatenated with test harnesses or execution runners. We demonstrate that in 87 of 100 reference execution failures in $T_1$ under naive concatenation, LLMs re-declare or stub the target function under test within their generated test code. Under naive concatenation, this redefinition dynamically overwrites both reference ($C_{\text{ref}}$) and faulty ($C_{\text{fault}}$) implementations in the execution namespace at runtime.

This infrastructural flaw introduces severe synthetic distortions:
1. **The Phantom Code Exposure Penalty:** Under naive execution, exposing implementation code appears to severely penalize defect detection ($-16.89$~pp, paired $t$-test $p = 0.025$).
2. **Disappearance of Penalty via Proper Scoping:** When evaluated under an AST-scoped clean harness that isolates assertion logic from target function definitions, this apparent penalty disappears; the point estimate becomes positive ($+12.89$~pp), though it does not reach statistical significance at $\alpha = 0.05$ ($p = 0.0791$, Holm-adjusted $p = 0.2374$). This demonstrates that the negative penalty was an artifact of harness execution mechanics rather than model cognitive deficiency.
3. **Model & Architecture Sensitivities:** We further quantify a secondary harness artifact—hypothetical module import sensitivity (`ModuleNotFoundError`)—which disproportionately penalizes models such as `qwen3.8-27b`, narrowing the cross-architecture gap from $15.11$~pp down to a lower bound of $5.78$~pp under the hypothetical assumption that all import crashes would convert to detections.

### Methodological Rigor & Data Availability
Our empirical evaluation encompasses a balanced $2 \times 2$ factorial design spanning 900 primary evaluations across 15 clustered benchmark problems under an unconstrained 2048-token generation budget, complemented by a 900-trial 512-token pilot study. We apply rigorous cluster-robust (Liang–Zeger) logistic regression and non-parametric cluster bootstrap methods.

In strict adherence to the Open Science and reproducibility standards of Springer Nature:
- The manuscript is accompanied by a turnkey, comprehensive replication package (`Replication_Package_2048.zip`).
- All 1,800 evaluation records across primary and pilot studies are provided in transparent, sanitized JSONLines and CSV formats.
- All benchmark manifests, AST-scoping harnesses, and deterministic verification scripts (`verify_all.py` and `audit_journal_standards.py`) are fully open-source with published SHA-256 checksums.
- Upon acceptance, the repository will be permanently preserved under a persistent Zenodo DOI.

This manuscript is original work, has not been published previously, and is not currently under consideration for publication elsewhere. All ethical declarations and disclosures have been made in full accordance with Springer Nature guidelines.

Thank you for your time and consideration of our manuscript.

Sincerely,

**Ziad Emad Allam**  
The American University in Cairo (AUC), New Cairo, Egypt  
Corresponding Author  
Email: `z.e.ziad@xed.aucegypt.edu`  
ORCID: `0009-0008-4323-791X`
